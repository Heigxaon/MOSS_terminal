"""
此文件夹下的所有py文件，在每次用户输入后会依次执行
------------------------------
无法使用import，以下库可直接使用
os, io, re, sys, time, json, random, base64, requests, 
threading, subprocess, Image, copy, shutil, difflib, 
readline, qrcode, marshal, signal

from collections import defaultdict
from datetime import datetime, timedelta
from openai import OpenAI
------------------------------
可访问的全局变量名：
    发送的内容：prompt
    群名: title
    发送者：sender
    原始消息：_msg
    发送消息函数：send_chat(content, at=True)  此函数在'!name auto'时生效
    图片像素化打印：pixel_art(image_path)
------------------------------
⚠️ 指定相对路径时以MOSS主程序为参照，不以本文件为参照
------------------------------
自己写功能，例：
    if prompt.startswith("!len "):
        result = f"字数: {len(prompt[5:])}"
        print(result)
        send_chat(result)
        raise  # 表示continue，不继续往下
这是一个字数统计指令，打印结果且发送到QQ
"""

# 以下是示例：

def get_nasa_apod():
    """获取NASA每日天文图片"""
    try:
        url = f"https://api.nasa.gov/planetary/apod?api_key=dYhYcQOMYEcBQRf633t1LVhtQW7G8nQdKylipgiS"
        response = requests.get(url)
        data = response.json()
        hdurl = data.get('hdurl')
        print("\n\033[93m==== NASA 每日天文图片 ====\033[0m")
        print(f"标题: \033[96m{data.get('title')}\033[0m")
        print(f"日期: {data.get('date')}")
        print(f"说明: \033[90m{data.get('explanation')}\033[0m")
        print(f"图片: \033[4;94m{hdurl}\033[0m")
        os.system(f'termux-open-url "{hdurl}" > /dev/null 2>&1')
    except Exception as e:
        print(f"\033[91m{e}\033[0m")






"""
实际外部结构：
while True:
    ...
    prompt = input()
    ...
    try:
        exec(plugin)  # 此文件在这个位置用exec()执行，仅raise可触发continue
    except:
        continue
    继续后面的主程序...
"""


if prompt == "!nasa":
    get_nasa_apod()
    raise
